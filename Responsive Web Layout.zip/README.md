
  # Responsive Web Layout

  This is a code bundle for Responsive Web Layout. The original project is available at https://www.figma.com/design/CVAaIEImJ2vHWLqKcRLKiC/Responsive-Web-Layout.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  